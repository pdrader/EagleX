    <!-- Begin page content -->
 
      <div class="page-header">
        <h5>Statements</h5>
      </div>
      <div class="content">
      <div class="row justify-content-md-center">
      <div class="col-12">
      
     


<table class="table table-striped">
  <thead>
    <tr>
     
      <th scope="col">Driver Name</th>
      <th scope="col">Check Date</th>
      <th scope="col">Truck Number</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>


  <?php 

foreach($statement_details as $statement_detail){
?>
    <tr>     
      <td><?php  echo $statement_detail['name']; ?></td>
      <td><?php  echo date("m/d/Y", strtotime($statement_detail['check_date']));   ?></td>
      <td><?php  echo $statement_detail['truck_number']; ?></td>

      <td>
        <a  href="<?php echo base_url('admin/run/'.$statement_detail['driver_id'].'/'.strtotime($statement_detail['check_date']).'/'.$statement_detail['truck_id']) ?>" class="btn btn-success default-btn">RUN</a>
<?php if($statement_detail['status']=='Approved') {?>
        <a  href="<?php echo base_url('admin/view/'.$statement_detail['driver_id'].'/'.strtotime($statement_detail['check_date']).'/'.$statement_detail['truck_id']) ?>" class="btn btn-success default-btn">Pay Statement</a>
    <?php }else { ?>
      <a    class="btn btn-success default-btn disabled">Pay Statement</a>
      <?php
}

    ?>
     <a  href="<?php echo base_url('admin/statement/delete/'.$statement_detail['driver_id'].'/'.strtotime($statement_detail['check_date']).'/'.$statement_detail['truck_id']) ?>" class="btn btn-danger delete-confirm ">Delete</a>
      </td>
    </tr>
<?php
}
?>

 
  </tbody>
</table>
</div>
<div class="col-12 pagination-main">
<?= $pager->links('default', 'bootstrap'); ?>


      </div>
       
      </div>
      </div>

   

   