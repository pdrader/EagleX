 
  
  <?php
	echo view($main_content);
  ?>
  </div>
  