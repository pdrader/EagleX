<footer class="mt-auto" id="site-footer">
      <div class="container">
      <div class="copyright">
        © Copyright <strong><span>EagleX</span></strong>. All Rights Reserved
      </div>
      </div>
    </footer>

  </body>
</html>